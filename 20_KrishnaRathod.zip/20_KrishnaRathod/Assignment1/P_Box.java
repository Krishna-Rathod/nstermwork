import java.util.*;
class P_Box
{
	static String encryption(String msg)
	{
		byte arr[]=new byte[10];
		byte msg_arr[]=new byte[10];
		msg_arr=msg.getBytes();
		arr[0]=msg_arr[8];
		arr[1]=msg_arr[7];
		arr[2]=msg_arr[6];
		arr[3]=msg_arr[4];
		arr[4]=msg_arr[9];
		arr[5]=msg_arr[5];
		arr[6]=msg_arr[3];
		arr[7]=msg_arr[1];
		arr[8]=msg_arr[2];
		arr[9]=msg_arr[0];
		return(new String(arr));
	}
	static String decryption(String msg)
	{
		byte arr[]=new byte[10];
		byte msg_arr[]=new byte[10];
		
		msg_arr=msg.getBytes();
		arr[0]=msg_arr[9];
		arr[1]=msg_arr[7];
		arr[2]=msg_arr[8];
		arr[3]=msg_arr[6];
		arr[4]=msg_arr[3];
		arr[5]=msg_arr[5];
		arr[6]=msg_arr[2];
		arr[7]=msg_arr[1];
		arr[8]=msg_arr[0];
		arr[9]=msg_arr[4];
		
		
		
		return(new String(arr));
		
	}
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.print("Enter your string::-");
		String msg=s.nextLine();
		String encryption_txt=encryption(msg);
		System.out.println("Your encrypted text::-"+encryption_txt);
		String decryption_txt=decryption(encryption_txt);
		System.out.println("Your decrypted text::-"+decryption_txt);
	}
	
}