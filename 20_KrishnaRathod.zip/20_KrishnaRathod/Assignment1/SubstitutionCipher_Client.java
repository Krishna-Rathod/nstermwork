import java.io.*;
import java.net.*;
import java.util.*;
class SubstitutionCipher_Client
{
	public static String serverside_msg(byte[] arr)
	{
	
		String dec_txt=" ";
		int i=0;
		while(arr[i]!=0)
		{
			dec_txt= dec_txt+(char)arr[i];
			i++;
		}
	
		return dec_txt;
	}
	public static String read_data() throws IOException
	{
		Scanner s=new Scanner(System.in);
		
		String filename=s.nextLine();
		
		int ch;
		String str="";
		FileInputStream in=new FileInputStream(filename +".txt");
		while((ch=in.read())!=-1)
		{
			str=str+(char)ch;
		}
		in.close();
		return str;
	}
	public static String encryption(String str)throws Exception
	{
		String enc_text="";
		System.out.print("Enter the file name for fetching key::-");
		String no=read_data();
		int n=Integer.parseInt(no);
		for(int i=0;i<str.length();i++)
		{
		
			char ch=str.charAt(i);
			if(Character.isUpperCase(ch))
			{
				int asc_ch=(((int)ch+n)-65)%26+65;
				enc_text=enc_text+(char)asc_ch;
			
			}
			else
			{
				int asc_ch=(((int)ch+n)-97)%26+97;
				enc_text=enc_text+(char)asc_ch;
			}
		}
		return  enc_text;
	}
	public static void main(String args[])throws Exception
	{
		
		String str="";
		System.out.print("\nEnter the file name from which u want to take input::-");
		str=read_data();
		String enc_text=encryption(str);
		
		DatagramSocket data_socket=new DatagramSocket(6789);
		InetAddress ip=InetAddress.getLocalHost();
		byte s_arr[]=null;
		s_arr=enc_text.getBytes();
		DatagramPacket data_packet=new DatagramPacket(s_arr,s_arr.length,ip,1234);
		data_socket.send(data_packet);
		byte[] r_arr=new byte[65335];
		data_packet=new DatagramPacket(r_arr,r_arr.length);
		data_socket.receive(data_packet);
		System.out.println("\nServer Side message::-"+serverside_msg(r_arr));
		
	}
}

