import java.io.*;
import java.net.*;
import java.util.*;
class SubstitutionCipher_Server
{
	
	public static String read_data() throws IOException
	{
		Scanner s=new Scanner(System.in);
		String filename=s.nextLine();
		int ch;
		String str="";
		FileInputStream in=new FileInputStream(filename +".txt");
		while((ch=in.read())!=-1)
		{
			str=str+(char)ch;
		}
		in.close();
		return str;
	}
	public static String client_msg(byte[] arr)
	{
		String enc_txt="";
		if(arr==null)
			return null;
		int i=0;
		while(arr[i]!=0)
		{
			enc_txt=enc_txt+(char)arr[i];
			i++;
		}
		return enc_txt;
	}
	public static String decryption(String str)throws Exception
	{
		System.out.print("\nEnter the file name for fetching key::-");
		String no=read_data();
		int n=Integer.parseInt(no);
		String dec_text="";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(Character.isUpperCase(ch))
			{
				int asc_ch=(((int)ch-n)-65)%26+65;
				dec_text=dec_text+(char)asc_ch;
			
			}
			else
			{
				int asc_ch=(((int)ch-n)-97)%26+97;
				dec_text=dec_text+(char)asc_ch;
			}
		}
		return  dec_text;
	}
	public static void main(String args[])throws Exception
	{
		Scanner s=new Scanner(System.in);
		DatagramSocket data_socket= new DatagramSocket(1234);
		byte[] rec_data=new byte[65335];
		DatagramPacket data_packet=new DatagramPacket(rec_data,rec_data.length);
		data_socket.receive(data_packet);
		String enc_txt=client_msg(rec_data);
		System.out.println("\nClient Side Message::-"+enc_txt);
		String dec_text=decryption(enc_txt);
		byte[] s_arr=new byte[65335];
		InetAddress ip=data_packet.getAddress();
		s_arr=dec_text.getBytes();
		data_packet=new DatagramPacket(s_arr,s_arr.length,ip,6789);
		data_socket.send(data_packet);
		data_socket.close();
	}
}